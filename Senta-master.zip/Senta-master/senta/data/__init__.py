# -*- coding: utf-8 -*
"""import"""
"""数据处理模块，数据的读取、id化、序列化、实例化等，相当于旧版的reader+encoder"""