# -*- coding: utf-8 -*
"""import"""
"""一些功能模块的集合，比如ernie、embedding、transformer等"""