# -*- coding: utf-8 -*
"""import"""
"""各网络的评估方式"""