rm -rf en
wget --no-check-certificate https://senta.bj.bcebos.com/skep/en.tar.gz .
tar zxvf en.tar.gz
rm -f en.tar.gz
