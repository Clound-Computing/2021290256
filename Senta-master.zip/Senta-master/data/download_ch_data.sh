rm -rf ch
wget --no-check-certificate https://senta.bj.bcebos.com/skep/ch.tar.gz .
tar zxvf ch.tar.gz
rm -f ch.tar.gz
